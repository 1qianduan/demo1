//跟随浮动
    window.onload=
        function(){
            var oDiv = document.getElementById("fixPara"),
                H = 0,
                Y = oDiv        
            while (Y) {
                H += Y.offsetTop; 
                Y = Y.offsetParent;
            }
            window.onscroll = function()
            {
                var s = document.body.scrollTop || document.documentElement.scrollTop
                if(s>H) {
                    oDiv.style = "position:fixed;top:80px;background-color:#fff;border-radius: 8px;"
                } else {
                    oDiv.style = "background-color:#fff;"
                }
            }
        }
		
//弹出层
function app() {
    var ecop = document.body;
    var app=document.getElementById('app');
	app.style.display="block";
	ecop.style="padding-right: 8px;overflow: hidden;"
}
function fenxiang() {
    var ecop = document.body;
    var fenxiang=document.getElementById('fenxiang');
	fenxiang.style.display="block";
	ecop.style="padding-right: 8px;overflow: hidden;"
}
function appon() {
    var ecop = document.body;
    var app=document.getElementById('app');
	var fenxiang=document.getElementById('fenxiang');
	app.style.display="none";
	fenxiang.style.display="none";
	ecop.style=""
}



