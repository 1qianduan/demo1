<?php
return array (
  'dscms' => 
  array (
    'slide' => '1',
    'module' => 
    array (
      0 => 'index_level',
      1 => 'index_hto',
      2 => 'index_art',
      4 => 'index_zhibo',
      5 => 'index_actor',
      6 => 'index_topic',
      7 => 'index_hezuo',
    ),
    'zhiboul' => 'http://127.0.0.1/index.php/vod/type/id/zhibo.html',
    'taobaoul' => 'http://demo.dataoke.com/',
    'logtype' => '1,2,3,4',
    'hnum' => '2.5',
    'indexactor' => '1',
    'gx' => 
    array (
      'debugging' => '0',
      'zt' => '0',
      'btn' => '0',
      'donghua' => '1',
      'lazy1' => '/template/ec_IQ/images/load.gif',
      'lazy2' => '/template/ec_IQ/images/ipcbg.gif',
      'lazy3' => '/template/ec_IQ/images/adminavr.jpeg',
      'soconet' => '短视cms多功能主题',
    ),
    'nav' => 
    array (
      'actor' => '1',
      'topic' => '1',
      'vip' => '1',
      'ivi' => '1',
      'zdyname1' => 'aaa1',
      'zdyurl1' => 'aaa',
      'zdyname2' => 'aaa2',
      'zdyurl2' => 'aaa',
    ),
    'viptc' => '1',
    'aa01' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_IQ/images/1760X140.jpg" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'aa02' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_IQ/images/1760X140.jpg" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'aa03' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_IQ/images/1760X140.jpg" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'aa04' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_IQ/images/vip1.png" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'aa06' => '<a class="playpcgu" href="#"><img src="/template/ec_IQ/images/pca-pc.png" height="100%" width="100%"></a>',
    'aa05' => '<div style="margin:10px 0;background-color: #f5f5f5;border-radius: 4px;"><a href="#" target="_blank"><img src="/template/ec_IQ/images/1760X140.jpg" style="height: 100%;display: block;border-radius: 4px;width: 100%;"></a></div>',
    'indextccont' => '1.如播卡顿或失败可切换片源。<br/>2.建议选择腾讯视频,爱奇艺,优酷等片源播放，速度更快画质更好，如播放失败可点击切换线路。<br/>3.请不要相信视频中的广告,视频中广告非本站所加。<br/>4.如需下载缓存视频使用QQ手机浏览器访问播放页即可看到下载按钮。',
    'publiclist' => '1',
    'public' => '0',
    'seo' => 
    array (
      'votitle' => '高清在线播放',
      'actitle' => '全部电影作品',
    ),
    'pd' => 
    array (
      'detailart' => '1',
      'jxxlof' => '1',
      'jxxl' => 'https://vip.ikjiexi.top/?url=,https://jiexi.380k.com/?url=,https://vip.66parse.club/?url=,https://z1.m1907.cn/?jx=',
      'gzh' => '/template/ec_IQ/images/ewm.png',
      'zhifubao' => '/template/ec_IQ/images/null.jpg',
      'weixin' => '/template/ec_IQ/images/null.jpg',
      'anma' => '/template/ec_IQ/images/ewm.png',
      'pingma' => '/template/ec_IQ/images/ewm.png',
      'anul' => '',
      'pingul' => '',
      'qqul' => '',
      'vodpl' => '1',
      'ratpl' => '1',
    ),
  ),
);